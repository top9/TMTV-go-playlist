# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import time


addon = xbmcaddon.Addon('pvr.iptvsimple')

try:
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format('pvr.iptvsimple'))
    addon.setSetting('useEpgGenreText', 'true')
    addon.setSetting('genresPathType', '0')
    addon.setSetting('genresPath', 'special://home/addons/script.tvgo.playlist/resources/lib/genres/genres.xml')
    time.sleep(3)
    xbmcgui.Dialog().notification("TV GO Playlist","Nastaveno", xbmcgui.NOTIFICATION_INFO, 4000, sound = True)
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
except:
    xbmcgui.Dialog().notification("TV GO Playlist","Chyba", xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
