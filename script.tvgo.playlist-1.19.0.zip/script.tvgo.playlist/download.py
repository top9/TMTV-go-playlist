# -*- coding: utf-8 -*-
import xbmc, time
from datetime import datetime
from resources.lib import tvgo


def get_sec(time_str):
    h, m, s = time_str.split(':')
    return int(h) * 3600 + int(m) * 60 + int(s)


def main():
    name = xbmc.getInfoLabel('ListItem.ChannelName')
    duration = get_sec(xbmc.getInfoLabel('ListItem.Duration(HH:mm:ss)'))
    epg = xbmc.getInfoLabel('ListItem.FileName').replace(".epg", "").replace(" ", "T")
    start = int(datetime.fromisoformat(epg).timestamp()) + abs(time.timezone)
    catchup = str(start) + "-" + str(start + duration)
    time_name = datetime.fromtimestamp(start).strftime('%Y-%m-%d_%H-%M-%S')
    file_name = name.replace(":", " ").replace("/", " ").replace(" ", "_") + "_" + time_name
    tvgo.record(name, catchup, file_name)


if (__name__ == "__main__"):
    main()